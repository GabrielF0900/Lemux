/*Inicio da interação dos botoes*/

const botaoinicio = document.querySelector(".inicio");
botaoinicio.addEventListener("click", (event) => {
    console.log("Voce clicou no botao INICIO.");
});

const botaosobrenos = document.querySelector(".sobrenos");
botaosobrenos.addEventListener("click", (event) => {
    console.log("Voce clicou no botao Sobre Nós.");
});

const botaoobjetivos = document.querySelector(".objetivos");
botaoobjetivos.addEventListener("click", (event) => {
    console.log("Voce clicou no botao Objetivos.");
});

const botaoservicos = document.querySelector(".servicos");
botaoservicos.addEventListener("click", (event) => {
    console.log("Voce clicou no botao Serviços.");
});

const botaocontato = document.querySelector(".contato");
botaocontato.addEventListener("click", (event) => {
    console.log("Voce clicou no botao Contato.");
});

/*Fim da interação dos botoes.*/

/*Inicio da interação dos botoes de próximo*/

document.addEventListener("DOMContentLoaded", () => {
    const proximoprincipal = document.querySelector(".proximo_principal");
    proximoprincipal.addEventListener("click", (event) => {
        console.log("Voce clicou no botao de próximo.");
    });

    const proximosecundario = document.querySelector(".proximo_secundario");
    proximosecundario.addEventListener("click", (event) => {
        console.log("Voce clicou no botao de próximo.");
    });

    const proximoterciario = document.querySelector(".proximo_terciario");
    if (proximoterciario) {
        proximoterciario.addEventListener("click", (event) => {
            console.log("Voce clicou no botao de próximo.");
        });
    }

    const proximo_principal = document.querySelector(".proximo_servicos1");
    if (proximo_principal) {
        proximo_principal.addEventListener("click", (event) => {
            console.log("Voce clicou no botao de próximo.");
        });
    }

    const proximo_secundario = document.querySelector(".proximo_servicos2");
    if (proximo_secundario) {
        proximo_secundario.addEventListener("click", (event) => {
            console.log("Voce clicou no botao de próximo.");
        });
    }

    const proximo_terciario = document.querySelector(".proximo_servicos3");
    if (proximo_terciario) {
        proximo_terciario.addEventListener("click", (event) => {
            console.log("Voce clicou no botao de próximo.");
        });
    }
});
    /*Fim da interação dos botoes de próximo*/ 