/*Inicio da interação dos botoes*/

document.addEventListener("DOMContentLoaded", () => {
    const botaoinicio = document.querySelector(".inicio");
    if (botaoinicio) {
        botaoinicio.addEventListener("click", (event) => {
            console.log("Voce clicou no botao INICIO.");
        });
    }

    const botaosobrenos = document.querySelector(".sobrenos");
    if (botaosobrenos) {
        botaosobrenos.addEventListener("click", (event) => {
            console.log("Voce clicou no botao Sobre Nós.");
        });
    }

    const botaoobjetivos = document.querySelector(".objetivos");
    if (botaoobjetivos) {
        botaoobjetivos.addEventListener("click", (event) => {
            console.log("Voce clicou no botao Objetivos.");
        });
    }

    const botaoservicos = document.querySelector(".servicos");
    if (botaoservicos) {
        botaoservicos.addEventListener("click", (event) => {
            console.log("Voce clicou no botao Serviços.");
        });
    }

    const botaocontato = document.querySelector(".contato");
    if (botaocontato) {
        botaocontato.addEventListener("click", (event) => {
            console.log("Voce clicou no botao Contato.");
        });
    }

    /*Fim da interação dos botoes.*/

    /*Inicio da interação dos botoes de próximo*/

    const proximoprincipal = document.querySelector(".proximo_principal");
    if (proximoprincipal) {
        proximoprincipal.addEventListener("click", (event) => {
            console.log("Voce clicou no botao de próximo.");
        });
    }

    const proximosecundario = document.querySelector(".proximo_secundario");
    if (proximosecundario) {
        proximosecundario.addEventListener("click", (event) => {
            console.log("Voce clicou no botao de próximo.");
        });
    }

    const proximoterciario = document.querySelector(".proximo_terciario");
    if (proximoterciario) {
        proximoterciario.addEventListener("click", (event) => {
            console.log("Voce clicou no botao de próximo.");
        });
    }

    const proximo_principal = document.querySelector(".proximo_servicos1");
    if (proximo_principal) {
        proximo_principal.addEventListener("click", (event) => {
            console.log("Voce clicou no botao de próximo.");
        });
    }

    const proximo_secundario = document.querySelector(".proximo_servicos2");
    if (proximo_secundario) {
        proximo_secundario.addEventListener("click", (event) => {
            console.log("Voce clicou no botao de próximo.");
        });
    }

    const proximo_terciario = document.querySelector(".proximo_servicos3");
    if (proximo_terciario) {
        proximo_terciario.addEventListener("click", (event) => {
            console.log("Voce clicou no botao de próximo.");
        });
    }

    /*Fim da interação dos botoes de próximo*/

    /*Inicio da interação do formulário*/

    const nomes = [];
    const contatos = [];
    const emails = [];
    const mensagens = [];

    const formulario = document.querySelector(".formulario form");
    if (formulario) {
        formulario.addEventListener("submit", (event) => {
            event.preventDefault(); // Impede o envio do formulário

            const nome = document.getElementById("nome").value.trim();
            const contato = document.getElementById("contato").value.trim();
            const email = document.getElementById("email").value.trim();
            const mensagem = document.getElementById("mensagem").value.trim();

            // Verifica se os campos não estão vazios
            if (!nome || !contato || !email || !mensagem) {
                alert("Por favor, preencha todos os campos.");
                return;
            }

            // Verifica se o email é válido
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(email)) {
                alert("Por favor, insira um email válido.");
                return;
            }

            // Adiciona os valores aos arrays correspondentes
            nomes.push(nome);
            contatos.push(contato);
            emails.push(email);
            mensagens.push(mensagem);

            // Exibe uma mensagem de confirmação
            alert("Formulário enviado com sucesso!");

            // Limpa os campos do formulário
            formulario.reset();

            // Exibe os arrays no console (opcional)
            console.log("Nomes:", nomes);
            console.log("Contatos:", contatos);
            console.log("Emails:", emails);
            console.log("Mensagens:", mensagens);
        });
    }

    /*Fim da interação do formulário*/
});